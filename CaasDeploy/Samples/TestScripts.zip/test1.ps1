 param (
    [string]$foo = "Foo"
 )
 

write-output "Hello from test.ps1"
write-output $foo >> "c:\hi.txt"
